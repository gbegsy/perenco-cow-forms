# Perenco UK CoW Assurance — Exact Forms UAT

Streamlit UAT build using the source Perenco question wording.

- No PDi BAR scoring or BAR escalation logic.
- No question rewording.
- PTW and Toolbox Talk questions come from the Perenco two-form source workbook.
- Leadership Engagement questions come from the original Control of Work Leadership Engagement Checklist.
- SQLite is used only as a simple persistent UAT store.
- Dashboard Export produces question-level CSV for the existing dashboard mapping.

Run with:

    pip install -r requirements.txt
    streamlit run app.py
